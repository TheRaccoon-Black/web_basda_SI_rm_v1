<link rel="stylesheet" type="text/css" href="style2.css">
<div class="h">Rumah Makan Bundo</div>
<div class="mbg">
	<a href="after_login.php" class="menu">Pesanan pelanggan</a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<a href="makanan.php" class="menu">Menu Makanan</a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<a href="galeri.php" class="menu">Galeri</a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<a href="review.php" class="menu">Review</a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<!--<a href="kategori.php" class="menu">kategori makanan</a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-->
	<a href="laporan.php" class="menu">laporan</a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<a href="logout.php" class="menu" style="color: red;">Logout</a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	
</div>
<br><br>
