<?php 
session_start();
$uid = $_SESSION['uid'];
include "header.php"; 
?>
<style type="text/css">
    tr{
    }
    tr:hover{
        background-color: lightgreen;
        color: black;
    }
</style>
<div style="height: 150px;"></div>
<div style="width: 90%; margin: 0 auto;">
<center> <p style="font-size: 2.4em; color: red">Lihat semua laporan disini</p> </center> 
    <div style="width: 90%; padding: 20px; text-align: right;">
    <br>
    <div>
        <?php 
        include "connect.php";
        $s = mysqli_query($con,"SELECT *, tambah_keranjang.harga, tambah_keranjang.tanggal, tambah_keranjang.bulan, tambah_keranjang.tahun 
                                FROM checkout 
                                INNER JOIN tambah_keranjang ON checkout.p_id = tambah_keranjang.p_id");

        // Tabel Checkout
        ?>
        <h2>Data Checkout</h2>
        <table border=1 width="80%" align="center" cellpadding="8" cellspacing="10" style="color: black">
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>ID produk</th>
                <th>Harga</th>
                <th>Nomor HP</th>
                <th>Email</th>
                <th>Alamat</th>
                <th>Tanggal</th>
                <th>Bulan</th>
                <th>Tahun</th>
            </tr>

            <?php
            $row_number = 1;

            while($r = mysqli_fetch_array($s)) {
            ?>
                <tr>
                    <td><?php echo $row_number; ?></td>
                    <td><?php echo $r['u_id']; ?></td>
                    <td><?php echo $r['p_id']; ?></td>
                    <td><?php echo $r['harga']; ?></td>
                    <td><?php echo $r['hp']; ?></td>
                    <td><?php echo $r['email']; ?></td>
                    <td><?php echo $r['lokasi']; ?></td>
                    <td><?php echo $r['tanggal']; ?></td>
                    <td><?php echo $r['bulan']; ?></td>
                    <td><?php echo $r['tahun']; ?></td>
                </tr>
            <?php
                $row_number++; 
            }
            ?>
        </table>

        <br>
        <hr>

        <?php
        // Tabel Rekap
        $s = mysqli_query($con,"SELECT *, WEEK(tambah_keranjang.tanggal) AS minggu, MONTH(tambah_keranjang.tanggal) AS bulan, YEAR(tambah_keranjang.tanggal) AS tahun, 
                                SUM(checkout.harga) AS total_harga, SUM(checkout.kuant) AS total_kuantitas
                                FROM checkout 
                                INNER JOIN tambah_keranjang ON checkout.p_id = tambah_keranjang.p_id
                                GROUP BY WEEK(tambah_keranjang.tanggal), MONTH(tambah_keranjang.tanggal), YEAR(tambah_keranjang.tanggal)");

?>
<h2>Data Rekap</h2>
<table border=1 width="80%" align="center" cellpadding="8" cellspacing="10" style="color: black">
    <tr>
        <th>No</th>
        <th>Minggu</th>
        <th>Bulan</th>
        <th>Tahun</th>
        <th>Total Harga</th>
        <th>Total Kuantitas</th>
    </tr>

    <?php
    $row_number = 1;

    while($r = mysqli_fetch_array($s)) {
    ?>
        <tr>
            <td><?php echo $row_number; ?></td>
            <td><?php echo $r['minggu']; ?></td>
            <td><?php echo $r['bulan']; ?></td>
            <td><?php echo $r['tahun']; ?></td>
            <td><?php echo $r['total_harga']; ?></td>
            <td><?php echo $r['total_kuantitas']; ?></td>
        </tr>
    <?php
        $row_number++; 
    }
    ?>
</table>
<div style="width: 90%; padding: 20px; text-align: right;">
    <br>
    <div>
        <?php 
        include "connect.php";
        $s = mysqli_query($con, "SELECT *, tambah_keranjang.harga, tambah_keranjang.tanggal, tambah_keranjang.bulan, tambah_keranjang.tahun FROM checkout INNER JOIN tambah_keranjang ON checkout.p_id = tambah_keranjang.p_id WHERE tambah_keranjang.bulan = MONTH(CURRENT_DATE())");
        ?><center><h2>Rekap Bulanan</h2></center>
        <table border="1" width="80%" align="center" cellpadding="8" cellspacing="10" style="color: black">
        <tr>
            <th>No</th>
            <th>Nama</th>
            <th>ID produk</th>
            <th>Harga</th>
            <th>Nomor HP</th>
            <th>Email</th>
            <th>Alamat</th>
            <th>Tanggal</th>
            <th>Bulan</th>
            <th>Tahun</th>
        </tr>

        <?php
        $row_number = 1;

        while ($r = mysqli_fetch_array($s)) {
        ?>
            <tr>
                <td><?php echo $row_number; ?></td>
                <td><?php echo $r['u_id']; ?></td>
                <td><?php echo $r['p_id']; ?></td>
                <td><?php echo $r['harga']; ?></td>
                <td><?php echo $r['hp']; ?></td>
                <td><?php echo $r['email']; ?></td>
                <td><?php echo $r['lokasi']; ?></td>
                <td><?php echo $r['tanggal']; ?></td>
                <td><?php echo $r['bulan']; ?></td>
                <td><?php echo $r['tahun']; ?></td>
            </tr>
        <?php
            $row_number++; 
        }
        ?>
        </table>    
        <center> <h2>Rekap Mingguan</h2> </center> 
        <center> <p style="font-size: 2.4em; color: red">Lihat semua laporan disini</p> </center> 
    <div style="width: 90%; padding: 20px; text-align: right;">
        <br>
        <div>
            <?php 
            include "connect.php";

            // Query untuk mengambil data checkout dan tanggal dengan format "dd/mm/yyyy"
            $s = mysqli_query($con,"SELECT *, tambah_keranjang.harga, tambah_keranjang.tanggal, tambah_keranjang.bulan, tambah_keranjang.tahun 
                                    FROM checkout 
                                    INNER JOIN tambah_keranjang ON checkout.p_id = tambah_keranjang.p_id");

            // Mengelompokkan data checkout berdasarkan minggu
            $weekly_data = [];
            while($row = mysqli_fetch_array($s)) {
                $date = $row['tanggal'];
                $week_number = (int) ceil(substr($date, 0, 2) / 7); // Menghitung nomor minggu dari tanggal dengan format "dd/mm/yyyy"
                if(!isset($weekly_data[$week_number])) {
                    $weekly_data[$week_number] = [];
                }
                $weekly_data[$week_number][] = $row;
            }
            ?>

            <table border=1 width="80%" align="center" cellpadding="8" cellspacing="10" style="color: black">
                <tr>
                    <th>No</th>
                    <th>nama</th>
                    <th>ID produk</th>
                    <th>Harga</th>
                    <th>nomor hp</th>
                    <th>Email</th>
                    <th>Alamat</th>
                    <th>Tanggal</th>
                    <th>Minggu</th>
                    <th>Bulan</th>
                    <th>Tahun</th>
                </tr>

                <?php
                $row_number = 1;

                // Menampilkan data checkout berdasarkan minggu
                foreach($weekly_data as $week_number => $week_data) {
                    foreach($week_data as $r) {
                ?>
                        <tr>
                            <td><?php echo $row_number; ?></td>
                            <td><?php echo $r['u_id']; ?></td>
                            <td><?php echo $r['p_id']; ?></td>
                            <td><?php echo $r['harga']; ?></td>
                            <td><?php echo $r['hp']; ?></td>
                            <td><?php echo $r['email']; ?></td>
                            <td><?php echo $r['lokasi']; ?></td>
                            <td><?php echo $r['tanggal']; ?></td>
                            <td><?php echo $week_number; ?></td>
                            <td><?php echo $r['bulan']; ?></td>
                            <td><?php echo $r['tahun']; ?></td>
                        </tr>
                <?php
                        $row_number++; 
                    }
                }
                ?>
            </table>  
            <center>
        <h2>rekap tahunan</h2>
    </center> 

    <div style="width: 90%; padding: 20px; text-align: right;">
        <br>
        <div>
            <?php 
            include "connect.php";
            $s = mysqli_query($con,"SELECT *, tambah_keranjang.harga, tambah_keranjang.tanggal, tambah_keranjang.bulan, tambah_keranjang.tahun FROM checkout 
                INNER JOIN tambah_keranjang ON checkout.p_id = tambah_keranjang.p_id
                ORDER BY tambah_keranjang.tahun ASC");

            $year = '';
            $total = 0;
            ?>

            <table border=1 width="80%" align="center" cellpadding="8" cellspacing="10" style="color: black">
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>ID Produk</th>
                    <th>Harga</th>
                    <th>Nomor HP</th>
                    <th>Email</th>
                    <th>Alamat</th>
                    <th>Tanggal</th>
                    <th>Bulan</th>
                    <th>Tahun</th>
                </tr>

                <?php
                $row_number = 1;

                while($r = mysqli_fetch_array($s)) {
                    // jika tahun berbeda, maka tampilkan total transaksi tahun sebelumnya dan reset total transaksi ke 0
                    if ($r['tahun'] !== $year) {
                        if (!empty($year)) {
                            echo '<tr><td colspan="10">Total Transaksi Tahun '.$year.': Rp '.number_format($total).'</td></tr>';
                            $total = 0;
                        }

                        $year = $r['tahun'];
                    }

                    $total += $r['harga'];
                ?>
                    <tr>
                        <td><?php echo $row_number; ?></td>
                        <td><?php echo $r['u_id']; ?></td>
                        <td><?php echo $r['p_id']; ?></td>
                        <td><?php echo $r['harga']; ?></td>
                        <td><?php echo $r['hp']; ?></td>
                        <td><?php echo $r['email']; ?></td>
                        <td><?php echo $r['lokasi']; ?></td>
                        <td><?php echo $r['tanggal']; ?></td>
                        <td><?php echo $r['bulan']; ?></td>
                        <td><?php echo $r['tahun']; ?></td>
                    </tr>
                <?php
                    $row_number++; 
                }

                // tampilkan total transaksi untuk tahun terakhir
                if (!empty($year)) {
                    echo '<tr><td colspan="10">Total Transaksi Tahun '.$year.': Rp '.number_format($total).'</td></tr>';
                }
                ?>
            </table>  
    </div>
</div>
</div>
<?php include "footer.php"; ?>
</div> 
</body> 
</html>
