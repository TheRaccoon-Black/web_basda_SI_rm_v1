<?php
$q = $_GET['q'];

include "connect.php";

//belum fix
$sql="SELECT * FROM kategori_makanan WHERE nama_kat = '".$q."'";
$result = mysqli_query($con,$sql);

echo "<select name='scat' class='text'>";
while($row = mysqli_fetch_array($result)) {
  
  echo "<option value='" . $row['sub_cat'] . "'>". $row['sub_cat'] ."</option>";
  
}
echo "</select>";

?>