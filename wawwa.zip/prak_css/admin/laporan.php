<?php session_start();
	$uid = $_SESSION['uid'];
 include "header.php"; ?>
<style type="text/css">
	tr{

	}
	tr:hover{
		background-color: lightgreen;
		color: black;

	}
</style>
<div style="height: 150px;"></div>
<div style="width: 90%; margin: 0 auto;">
<center> <p style="font-size: 2.4em; color: red">Lihat smeua laporan disini</p> </center> 
	<div style="width: 90%; padding: 20px; text-align: right;">
	<br>
	<div>
		<?php include "connect.php";
			$s = mysqli_query($con,"select *,tambah_keranjang.harga,tambah_keranjang.tanggal,tambah_keranjang.bulan,tambah_keranjang.tahun from checkout INNER JOIN tambah_keranjang on checkout.p_id=tambah_keranjang.p_id");
		?>
		<table border=1 width="80%" align="center" cellpadding="8" cellspacing="10" style="color: black">
		<tr><th>No</th>
        <th>nama</th>
            <th>ID produk</th>
            <th>Harga</th>
			<th>nomor hp</th>
			<th>Email</th>
            <th>Alamat</th>
			<th>Tanggal</th>
			<th>Bulan</th>
			<th>Tahun</th>
		</tr>

		<?php
    $row_number = 1;

    while($r = mysqli_fetch_array($s)) {
?>
    <tr>
        <td><?php echo $row_number; ?></td>
        <td><?php echo $r['u_id']; ?></td>
        <td><?php echo $r['p_id']; ?></td>
        <td><?php echo $r['harga']; ?></td>
			<td><?php echo $r['hp']; ?></td>
			<td><?php echo $r['email']; ?></td>
			<td><?php echo $r['lokasi']; ?></td>
			<td><?php echo $r['tanggal']; ?></td>
			<td><?php echo $r['bulan']; ?></td>
			<td><?php echo $r['tahun']; ?></td>
    </tr>
<?php
        $row_number++; 
    }
		?>
		</table>	
	</div>
<button onclick="window.print()">cetak</button>


</div>
<?php
include "footer.php";
?>