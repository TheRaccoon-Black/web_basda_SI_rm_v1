<?php include "header.php"; ?>	
	<!-- Start All Pages -->
	<img src="images/logos.png" alt="" width="200" height="200" class="centered" />


</div>
	<!-- End All Pages -->
	
	<!-- Start Contact -->
	<div>
		<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3981.231142023998!2d102.27025531475898!3d-3.7597955972646724!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e36b1c18941d9f3%3A0x1aecc8afb80fdf02!2sUniversity%20of%20Bengkulu!5e0!3m2!1sen!2sid!4v1682595749823!5m2!1sen!2sid" width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>

	</div>
	<div class="contact-box">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="heading-title text-center">
						<h2>Kontak kami</h2>
						<p>Informasi kontak dapat dilihat di sini</p>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-12">
					<form id="contactForm">
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<h1 style="font-family: cambria; color: red; text-align: center;">Rumah makan Bundo</h1>
									<div class="help-block with-errors"></div>
								</div>                                 
							</div>
							<div class="col-md-12">
								<div class="form-group">
									<center><span style="color: tomato; font-size: 1.3em; text-align: center; "><b>Email :</b> kelompok6@gmail.com</span></center>
									<div class="help-block with-errors"></div>
								</div> 
							</div>
							<div class="col-md-12">
								<div class="form-group">
									<center><span style="color: tomato; font-size: 1.3em; text-align: center; "><b>Telpon  :</b> 0858-0000-0006</span></center>
									<div class="help-block with-errors"></div>
								</div> 
							</div>
							<div class="col-md-12">
								<div class="form-group"> 
									<center><span style="color: tomato; font-size: 1.3em; text-align: center; "><b>Lokasi  :</b> universitas bengkulu, bengkulu,indoneisa</span></center>
									<div class="help-block with-errors"></div>
								</div>
								
							</div>
						</div>            
					</form>
				</div>
			</div>
		</div>
	</div>
	<!-- End Contact -->
<?php include "footer.php"; ?>