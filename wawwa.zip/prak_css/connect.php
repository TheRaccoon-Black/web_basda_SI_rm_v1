<?php
	$con = mysqli_connect('localhost','root','admin','rm_baru');


?>